﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.SceneManagement;

/*
 * Source File Name:GameController.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: Game handler to control the lives, score, reset button, and displaying "GAME OVER" and High Score.
 * Revision History:
 *
*/

public class GameController : MonoBehaviour {
	//Fields
	[SerializeField] Text lblLife;
	[SerializeField] Text lblScore;
	[SerializeField] Text lblHighScore;
	[SerializeField] Text lblGameOver;
	[SerializeField] Button btnReset;

	//initialize score and life
	private int score = 0;
	private int life = 5;

	void Start () {
		//Create a player instance and call initialize
		Player.Instance.gameCTRL = this;
		initialize ();
	}

	// Update is called once per frame
	void Update () {

	}
	//Resets the scene when button is clicked
	public void ResetBtnClick(){
		SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
	}
	//Get/Set for Score
	public int Score{
		get{ return score; }
		set{
			score = value;
			lblScore.text = "Score: " + score;
		}
	}

	//Get/Set for Life
	public int Life{
		get{ return life; }
		set{
			life = value;

			if (life <= 0) {
				gameOver ();
			} else {
				lblLife.text = "Life: " + life;
			}
		}
	}

	//Get/Set for HighScore
	public int HighScore{
		get{return score; }
		set{
			score = value;
			lblHighScore.text = "High Score: " + score;
		}
	}

	private void initialize(){
		//Set Player score to 0 and life to 5
		Player.Instance.Score = 0;
		Player.Instance.Life = 5;

		//Disable "Game Over", "High Score" and Reset button from view
		lblGameOver.gameObject.SetActive (false);
		lblHighScore.gameObject.SetActive (false);
		btnReset.gameObject.SetActive (false);

		//Enable Life and Score bars for view
		lblLife.gameObject.SetActive (true);
		lblScore.gameObject.SetActive (true);
	}

	private void gameOver(){
		//Opposite of initialize
		HighScore = score;
		lblGameOver.gameObject.SetActive (true);
		lblHighScore.gameObject.SetActive (true);
		btnReset.gameObject.SetActive (true);

		lblLife.gameObject.SetActive (false);
		lblScore.gameObject.SetActive (false);


	}
}
