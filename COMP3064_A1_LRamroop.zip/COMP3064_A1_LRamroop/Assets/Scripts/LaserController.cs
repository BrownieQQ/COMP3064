﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:LaserController.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: How the laser operates.
 * Revision History:
 *
*/

public class LaserController : MonoBehaviour {
	[SerializeField] float speed = 5f;

	private Transform _transform;
	private Vector2 _currentPos;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
	}
	
	// Update is called once per frame
	void Update () {
		_currentPos = transform.position;
		_currentPos += new Vector2 (speed, 0);
		_transform.position = _currentPos;
		//destroys laser if it goes beyond the screen
		if (_currentPos.x > 250) {
			Destroy (gameObject);
		}
	}
}
