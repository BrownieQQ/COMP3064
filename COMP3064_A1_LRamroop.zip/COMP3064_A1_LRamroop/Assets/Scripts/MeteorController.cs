﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:MeteorController.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: How the meteors move.
 * Revision History:
 *
*/

public class MeteorController : MonoBehaviour {
	//Initializing the min and max speeds of the X/Y axis for the meteors
	[SerializeField] float minXSpeed = 2f;
	[SerializeField] float maxXSpeed = 10f;
	[SerializeField] float minYSpeed = 2f;
	[SerializeField] float maxYSpeed = 10f;

	private Transform _transform;
	private Vector2 _currentSpeed;
	private Vector2 _currentPos;
	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		Reset ();
	}

	public void Reset(){
		//random x and y speed
		float xSpeed = Random.Range (minXSpeed, maxXSpeed);
		float ySpeed = Random.Range (minYSpeed, maxYSpeed);

		_currentSpeed = new Vector2 (xSpeed, ySpeed);

		float x = Random.Range (-316, 179);
		_transform.position = new Vector2 (x, 177 + Random.Range (0,100));

	}
	// Update is called once per frame
	void Update () {
		_currentPos = transform.position;
		_currentPos -= _currentSpeed;
		_transform.position = _currentPos;

		if (_currentPos.y <= -177) {
			Reset ();
		}
	}
}
