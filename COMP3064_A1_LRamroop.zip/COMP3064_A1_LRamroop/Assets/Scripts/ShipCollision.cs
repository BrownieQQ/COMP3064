﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:ShipCollision.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: Handles how the ship reacts to a collision.
 * Revision History:
 *
*/

public class ShipCollision : MonoBehaviour {
	[SerializeField] GameController gameController;
	[SerializeField] GameObject explosion;

	private AudioSource _starPickUp;
	private AudioSource _enemyExplode;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnTriggerEnter2D(Collider2D other){
		//Checks if the Ship hit a enemy
		if(other.gameObject.tag.Equals("enemy")){
			Debug.Log("Collision enemy\n");
			//initializes the explosion and sets it's position to that of the enemy ship.
			Instantiate (explosion).GetComponent<Transform> ().position = other.gameObject.GetComponent<Transform>().position;
			//gets the explosion sound file and plays it, if it exists.
			_enemyExplode = other.gameObject.GetComponent<AudioSource> ();
			if (_enemyExplode != null) {
				_enemyExplode.Play ();
			}
			//resets the enemy ship, records a 100 points and you lose a life.
			other.gameObject.GetComponent<EnemyController>().Reset();
			gameController.Life--;
			gameController.Score+=100;
			//if player ship's life reaches 0, destroy player's ship
			if (gameController.Life == 0) {
				Destroy (gameObject);
			}
		}
		if(other.gameObject.tag.Equals("meteor")){
			Debug.Log("Collision meteor\n");
			gameController.Life--;
			if (gameController.Life == 0) {
				Destroy (gameObject);
			}
		}
		if (other.gameObject.tag.Equals ("points")) {
			Debug.Log ("Collision points\n");
			_starPickUp = other.gameObject.GetComponent<AudioSource> ();
			if (_starPickUp != null) {
				_starPickUp.Play ();
			}
			other.gameObject.GetComponent<StarController> ().Reset ();
			gameController.Score += 100;
		}
	}
}
