﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:LaserCollision.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: Handles how the laser reacts during a collision.
 * Revision History:
 *
*/

public class LaserCollision : MonoBehaviour {
	[SerializeField] GameObject explosion;

	private AudioSource _enemyExplode;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnTriggerEnter2D(Collider2D other){
		/*
		 * If laser collides with enemy,
		 * Initialize explosion set the position to the enemy,
		 * Get audio source, play audio,
		 * Destroy object and reset,
		 * Record 100 points.
		 */
		if (other.gameObject.tag.Equals ("enemy")) {
			Debug.Log ("Collision enemy!\n");
			Instantiate (explosion).GetComponent<Transform> ().position = other.gameObject.GetComponent<Transform>().position;
			_enemyExplode = other.gameObject.GetComponent<AudioSource> ();
			if (_enemyExplode != null) {
				_enemyExplode.Play ();
			}
			Destroy (gameObject);
			other.gameObject.GetComponent<EnemyController> ().Reset ();
			other.gameObject.GetComponent<GameController> ().Score += 100;
		}
	}
}
