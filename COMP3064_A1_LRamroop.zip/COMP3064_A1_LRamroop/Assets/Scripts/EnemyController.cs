﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
 * Source File Name:EnemyController.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: How the enemy ship moves and operates.
 * Revision History:
 *
*/
public class EnemyController : MonoBehaviour {

	[SerializeField] float minXSpeed = 5f;
	[SerializeField] float maxXSpeed = 10f;
	[SerializeField] float minYSpeed = 2f;
	[SerializeField] float maxYSpeed = 2f;

	private Transform _transform;
	private Vector2 _currentSpeed;
	private Vector2 _currentPos;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		Reset ();
	}

	public void Reset(){
		//getting a random speed based on preset variables
		float xSpeed = Random.Range (minXSpeed, maxXSpeed);
		float ySpeed = Random.Range (minYSpeed, maxYSpeed);

		//assigning the speed to a variable
		_currentSpeed = new Vector2 (xSpeed, 0);

		//passing a new start position for the enemy ship
		float y = Random.Range (152, -139);
		_transform.position = new Vector2 (177 + Random.Range (0,100), y);

	}
	// Update is called once per frame
	void Update () {
		//Retreives position from transform, assigns a new value and changes transform's position.
		_currentPos = transform.position;
		_currentPos -= _currentSpeed;
		_transform.position = _currentPos;

		//if enemy goes out of frame, reset it
		if (_currentPos.x <= -419) {
			Reset ();
		}
	}
}
