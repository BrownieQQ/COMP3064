﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:StarController.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: How the star moves and operates.
 * Revision History:
 *
*/

public class StarController : MonoBehaviour {

	//Public variables
	[SerializeField]
	private float speed = 5f;
	[SerializeField]
	private float topY = 157;
	[SerializeField]
	private float bottomY = -141;
	[SerializeField]
	private float startX;
	[SerializeField]
	private float endX;

	//private variables
	private Transform _transform;
	private Vector2 _currentPos;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		_currentPos = _transform.position;
		Reset ();
	}

	// Update is called once per frame
	void Update () {
		_currentPos = _transform.position;
		_currentPos -= new Vector2 (speed, 0);
		_transform.position = _currentPos;

		if (_currentPos.x <= endX || _currentPos.y >= topY || _currentPos.y <= bottomY) {
			//reset
			Reset ();
		}
	}


	public void Reset(){
		float y = Random.Range (topY, bottomY);
		_transform.position = new Vector2 (startX + Random.Range (0, 50), y);
	}
}
