﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:SpaceController.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: How the background moves.
 * Revision History:
 *
*/

public class SpaceController : MonoBehaviour {
	//initializing the background and speed at which it will move
	[SerializeField] private float speed = 5f;
	[SerializeField] private float startX;
	[SerializeField] private float endX;
	[SerializeField] private float posY;

	private Transform _transform;
	private Vector2 currentPos;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		currentPos = transform.position;
		Reset ();
	}
	
	// Update is called once per frame
	void Update () {
		currentPos = _transform.position;

		currentPos -= new Vector2 (speed, 0);

		if (currentPos.x < endX) {
			Reset ();
		}

		transform.position = currentPos;
	}

	private void Reset(){
		currentPos = new Vector2 (startX, posY);
	}
}
