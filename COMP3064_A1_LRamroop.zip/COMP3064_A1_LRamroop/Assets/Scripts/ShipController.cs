﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:ShipController.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: How the player ship moves.
 * Revision History:
 *
*/

public class ShipController : MonoBehaviour {

	[SerializeField] private float speed = 5f;
	[SerializeField] private float leftX;
	[SerializeField] private float rightX;
	[SerializeField] private float upY;
	[SerializeField] private float downY;
	[SerializeField] private GameObject laser;

	private Transform _transform;
	private Vector2 _currentPos;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		_currentPos = _transform.position;
	}
	
	// Update is called once per frame
	void Update () {

		_currentPos = _transform.position;

		if (Input.GetKey(KeyCode.LeftArrow)) {
			//if left arrow is pressed, move left
			_currentPos -= new Vector2(speed, 0);

		}
		if (Input.GetKey(KeyCode.RightArrow)) {
			//if left arrow is pressed, move left
			_currentPos += new Vector2(speed, 0);

		}
		if (Input.GetKey(KeyCode.UpArrow)) {
			//if up arrow is pressed, move up
			_currentPos += new Vector2(0, speed);

		}
		if (Input.GetKey(KeyCode.DownArrow)) {
			//if down arrow is pressed, move down
			_currentPos -= new Vector2(0, speed);

		}
		if (Input.GetKeyDown (KeyCode.Space)) {
			//if space is pressed, fire laser
			GameObject shoot = Instantiate (laser);
			shoot.transform.position = gameObject.transform.position;
		}
		//checks bounds before transforming position.
		CheckBounds ();
		_transform.position = _currentPos;
	}
	//Checks to make sure the player ship is not going out of bounds
	private void CheckBounds(){
		if (_currentPos.x < leftX) {
			_currentPos.x = leftX;
		}
		if (_currentPos.x > rightX) {
			_currentPos.x = rightX;
		}
		if (_currentPos.y > upY) {
			_currentPos.y = upY;
		}
		if (_currentPos.y < downY) {
			_currentPos.y = downY;
		}
	}
}
