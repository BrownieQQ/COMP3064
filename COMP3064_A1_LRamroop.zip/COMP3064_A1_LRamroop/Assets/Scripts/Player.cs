﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:Player.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: Holds player information
 * Revision History:
 *
*/

public class Player {

	static private Player _instance;
	static public Player Instance{
		get{ 
			if (_instance == null) {
				_instance = new Player ();
			}
			return _instance;
		}
	}
	private Player(){



	}

	public GameController gameCTRL;

	private int score = 0;
	private int life = 3;

	public int Score{
		get{ return score; }
		set{ 
			score = value;
			//scoreLabel.text = "Score: " + _score;
			//gCtrl.updateUI();
		}

	}

	public int Life{
		get{ return life; }
		set{ 
			life = value;


			if (life <= 0) {
				//game over
				//gCtrl.gameOver();
			}else{
				//lifeLabel.text = "Life: " + _life;
				//gCtrl.updateUI();
			}
		}
	}
}