﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Source File Name:Explosion.cs
 * Author's Name: Lakeram Ramroop
 * Last Modified by: Lakeram Ramroop
 * Date Last Modified: Oct 20, 2017
 * Program Descrption: A one line function .cs file that destroys the explosion object.
 * Revision History:
 *
*/

public class Explosion : MonoBehaviour {
	public void DestroyMe(){
		Destroy (gameObject);
	}
}
